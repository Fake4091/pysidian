<div align="center">
  <img style="width: 30%;" src="Pysidian.png" alt="pysidian logo">  
  
  # **PYSIDIAN**

  ## **DESCRIPTION**
  This program allows users to make notes, link/relate notes to other notes, and mark notes as important.

  COLOR PALETTE            |  DEMO
:-------------------------:|:-------------------------:
<img style="width: 100%;" src="palette.png" alt="Color Palette">   |  <video widith=100% controls><source src="Demo_Pysidian_copy.mp4" type="video/mp4">DEMO Video</video>
</div>

## **KEY FEATURES:**
a functional notes app that gives you freedom with relations and importance




